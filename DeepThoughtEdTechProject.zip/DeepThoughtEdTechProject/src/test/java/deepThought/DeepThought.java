package deepThought;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class DeepThought {
	private static WebDriver driver = null;

	public static void main(String[] args) throws Exception {

		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://dev.deepthought.education/login");
		Thread.sleep(3000);

		driver.findElement(By.xpath("//a[text()='Register']")).click();
		Thread.sleep(3000);

		driver.findElement(By.xpath("//label[text()='Email Address']")).click();
		driver.findElement(By.xpath("//input[@placeholder='Enter Email Address']")).sendKeys("XY78693@gmail.com");
		Thread.sleep(3000);

		driver.findElement(By.xpath("//label[text()='Username']")).click();
		driver.findElement(By.xpath("//input[@placeholder='Enter Username']")).sendKeys("Rahul211");
		Thread.sleep(3000);

		driver.findElement(By.xpath("//label[text()='Password']")).click();
		driver.findElement(By.xpath("//input[@placeholder='Enter Password']")).sendKeys("Xml211@");
		Thread.sleep(3000);

		driver.findElement(By.xpath("//label[text()='Confirm Password']")).click();
		driver.findElement(By.xpath("//input[@placeholder='Confirm Password']")).sendKeys("Xml211@");
		Thread.sleep(3000);

		driver.findElement(By.xpath("//button[text()='Register Now']")).click();
		Thread.sleep(3000);

		driver.findElement(By.xpath(
				"//strong[text()='I consent to the collection and processing of my personal information on this website.']"))
				.click();
		Thread.sleep(6000);

		driver.findElement(
				By.xpath("//strong[text()='I consent to receive digest and notification emails from this website.']"))
				.click();
		Thread.sleep(6000);

		driver.findElement(By.xpath("//button[text()='Submit']")).click();
		Thread.sleep(6000);

		driver.quit();

	}
}
