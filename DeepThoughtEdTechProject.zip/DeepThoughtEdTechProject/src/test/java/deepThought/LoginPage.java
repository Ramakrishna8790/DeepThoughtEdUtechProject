package deepThought;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class LoginPage {
	private static WebDriver driver = null;

	public static void main(String[] args) throws Exception {

		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.manage().window().maximize();

		driver.get("https://dev.deepthought.education/login");
		Thread.sleep(6000);

		driver.findElement(By.xpath("//label[text()='Username / Email']")).click();
		driver.findElement(By.xpath("//input[@placeholder='Username / Email']")).sendKeys("XY78693@gmail.com");
		Thread.sleep(3000);

		driver.findElement(By.xpath("//label[text()='Password']")).click();
		driver.findElement(By.xpath("//input[@placeholder='Password']")).sendKeys("Xml211@");
		Thread.sleep(3000);

		driver.findElement(By.xpath("//button[text()='Login']")).click();
		Thread.sleep(3000);

		driver.findElement(By.xpath("//span[text()='SDLMS']")).click();
		Thread.sleep(3000);

		driver.findElement(By.xpath("//span[text()='DTthon']")).click();
		Thread.sleep(3000);

		driver.findElement(By.xpath("//span[text()='PDGMS']")).click();
		Thread.sleep(3000);

		driver.findElement(By.xpath("//a[@id='dropdownMenuButton']")).click();
		Thread.sleep(3000);

		driver.findElement(By.xpath("//span[text()=' Logout']")).click();
		Thread.sleep(3000);

		driver.quit();
	}

}
